Execute or put BedwarsResourcePack in your autoexec
